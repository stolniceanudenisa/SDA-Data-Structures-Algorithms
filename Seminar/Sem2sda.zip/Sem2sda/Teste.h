#pragma once
void testSize();
void testAdd();
void testRemove();
void testSearch();
void testNrOccurences();
void testAll();
void testGetAt();
